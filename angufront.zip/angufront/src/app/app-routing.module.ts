import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ContactoComponent } from './contacto/contacto.component';
import { TerminosComponent } from './terminos/terminos.component';
import { InicioComponent} from './inicio/inicio.component';
import { VentasComponent } from './ventas/ventas.component';
import { TrituracionComponent } from './trituracion/trituracion.component';
import { CribadoComponent } from './cribado/cribado.component';
import { FregadoComponent } from './fregado/fregado.component';
import { ConcentracionComponent } from './concentracion/concentracion.component';
import { RecogidaComponent } from './recogida/recogida.component';
import { AdminComponent } from './admin/admin.component';
import { ActualizacionComponent } from './actualizacion/actualizacion.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent},
  { path: '' , component: HomeComponent},
  { path: 'login', component: LoginComponent,  pathMatch: 'full'},
  { path: 'register', component: RegisterComponent,  pathMatch: 'full'},
  { path: 'contacto', component: ContactoComponent,  pathMatch: 'full'},
  { path: 'terminos', component: TerminosComponent,  pathMatch: 'full'},
  { path: 'inicio', component: InicioComponent,  pathMatch: 'full'},
  { path: 'ventas', component: VentasComponent,  pathMatch: 'full'},
  { path: 'trituracion', component: TrituracionComponent,  pathMatch: 'full'},
  { path: 'cribado', component: CribadoComponent,  pathMatch: 'full'},
  { path: 'fregado', component: FregadoComponent,  pathMatch: 'full'},
  { path: 'concentracion', component: ConcentracionComponent,  pathMatch: 'full'},
  { path: 'recogida', component: RecogidaComponent,  pathMatch: 'full'},
  { path: 'admin', component: AdminComponent,  pathMatch: 'full'},
  { path: 'actualizacion', component: ActualizacionComponent,  pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
