import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ContactoComponent } from './contacto/contacto.component';
import { TerminosComponent } from './terminos/terminos.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './services/auth.service';
import { VentasComponent } from './ventas/ventas.component';
import { InicioComponent } from './inicio/inicio.component';
import { TrituracionComponent } from './trituracion/trituracion.component';
import { CribadoComponent } from './cribado/cribado.component';
import { FregadoComponent } from './fregado/fregado.component';
import { ConcentracionComponent } from './concentracion/concentracion.component';
import { RecogidaComponent } from './recogida/recogida.component';
import { AdminComponent } from './admin/admin.component';
import { ActualizacionComponent } from './actualizacion/actualizacion.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    ContactoComponent,
    TerminosComponent,
    VentasComponent,
    InicioComponent,
    TrituracionComponent,
    CribadoComponent,
    FregadoComponent,
    ConcentracionComponent,
    RecogidaComponent,
    AdminComponent,
    ActualizacionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CommonModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
