import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-concentracion',
  templateUrl: './concentracion.component.html',
  styleUrls: ['./concentracion.component.css']
})
export class ConcentracionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
