import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CribadoComponent } from './cribado.component';

describe('CribadoComponent', () => {
  let component: CribadoComponent;
  let fixture: ComponentFixture<CribadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CribadoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CribadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
