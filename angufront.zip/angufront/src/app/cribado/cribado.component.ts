import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cribado',
  templateUrl: './cribado.component.html',
  styleUrls: ['./cribado.component.css']
})
export class CribadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
