import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FregadoComponent } from './fregado.component';

describe('FregadoComponent', () => {
  let component: FregadoComponent;
  let fixture: ComponentFixture<FregadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FregadoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FregadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
