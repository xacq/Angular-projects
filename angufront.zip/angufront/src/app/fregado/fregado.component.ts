import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fregado',
  templateUrl: './fregado.component.html',
  styleUrls: ['./fregado.component.css']
})
export class FregadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
