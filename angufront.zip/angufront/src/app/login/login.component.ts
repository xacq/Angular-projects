import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
  }

  onLogin(form:any): void {
    this.authService.login(form.value).subscribe(res => {

      if (res.dataUser.type === 'admin') {
        Swal.fire(
          'Administrador Aceptado',
          'Click para continuar',
          'success'
        )
        this.router.navigateByUrl('/admin');
      }
      else {
        Swal.fire(
          'Usuario Aceptado',
          'Click para continuar',
          'success'
        )
        this.router.navigateByUrl('/inicio');
        }
    });
  }

}
