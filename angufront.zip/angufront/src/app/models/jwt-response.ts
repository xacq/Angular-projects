export interface JwtResponseI {
  dataUser: {
    id: number,
    name: string,
    email: string,
    type: string,
    paso1: string,
    paso2: string,
    paso3: string,
    paso4: string,
    paso5: string,
    accessToken: string,
    expiresIn: string
  }
}
