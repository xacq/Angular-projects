export interface UserI {
  id: number,
  name: string,
  email: string,
  password: string,
  type:string,
  paso1: string,
  paso2: string,
  paso3: string,
  paso4: string,
  paso5: string
}
