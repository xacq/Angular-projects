import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recogida',
  templateUrl: './recogida.component.html',
  styleUrls: ['./recogida.component.css']
})
export class RecogidaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
