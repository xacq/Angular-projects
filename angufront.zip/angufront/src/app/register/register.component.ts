import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { UserI } from '../models/user';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
  }

  onRegister(form:any): void {
    this.authService.register(form.value).subscribe(res => {
      try{
        Swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Usuario Registrado',
          showConfirmButton: false,
          timer: 1000
        })
        this.router.navigateByUrl('/login');
      }catch(error){
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Algo ha salido mal...!',
        })
        console.log(error);

      }
    });
  }

}