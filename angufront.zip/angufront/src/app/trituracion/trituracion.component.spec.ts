import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrituracionComponent } from './trituracion.component';

describe('TrituracionComponent', () => {
  let component: TrituracionComponent;
  let fixture: ComponentFixture<TrituracionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrituracionComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrituracionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
