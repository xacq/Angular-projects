import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trituracion',
  templateUrl: './trituracion.component.html',
  styleUrls: ['./trituracion.component.css']
})
export class TrituracionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
